package io.github.lahuman.sk101

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringKotlin101ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
